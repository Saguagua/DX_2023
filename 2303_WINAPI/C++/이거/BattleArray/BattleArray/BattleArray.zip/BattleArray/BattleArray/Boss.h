#pragma once
#include "framework.h"
class Boss : public Monster
{
public:
	Boss():Monster("����", 300, 25, 20) {}
private:
	
};

