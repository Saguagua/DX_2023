#pragma once
#include "framework.h"

class Archer : public Player
{
public:
	Archer(string name, int hp, int atk, int crit) : Player(name, hp, atk, crit+20) {}
	// Player��(��) ���� ��ӵ�
	virtual void Skill(Creature* const target) override;
};

