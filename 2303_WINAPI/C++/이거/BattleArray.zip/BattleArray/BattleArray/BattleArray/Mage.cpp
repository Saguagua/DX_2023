#include "framework.h"

void Mage::Skill(Creature* const target)
{
}
