#include "framework.h"

void Archer::Skill(Creature* const target)
{
}
