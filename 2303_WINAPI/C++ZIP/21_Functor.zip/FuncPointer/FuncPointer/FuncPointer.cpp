﻿#include <iostream>
#include <algorithm>

using namespace std;

void PrintHello(void)
{
	cout << "Hello World!" << endl;
}

void PrintInfo()
{
	cout << "제 이름은 최한일입니다." << endl;
}

void PrintInt(int value)
{
	cout << "Value : " << value << endl;
}

// 함수 포인터
// 함수를 가리키는 포인터 변수

// typedef
class Pet;

typedef void(*FN)(void);
typedef void(*FN1)(int);
typedef void(Pet::* FN_Pet)(void);
typedef unsigned int UINT;

FN ptr; // 함수 시그니쳐
// 함수를 담는 포인터 변수 선언
// 함수 이름은 포인터와 똑같이 동작한다.

FN1 ptr1;

// 함수 포인터의 사용법
// -> 나중에 세팅된 함수로, 서로 다른 작업을 할 수 있다.
// => 콜백함수

// 멤버함수포인터는 어떻게 쓸까?

// 콜백함수
// - 함수를 미리 세팅
// - 어떠한 이벤트가 발생했을 때 세팅된 함수를 취사 선택하여 쓸 수 있다.
// => Pet이 짖는 함수를 정의 해두고
// => Player가 이벤트를 발생시키면 Pet이 짖는다.

class Pet
{
public:
	void Bark() { cout << "왈왈!" << endl; }
};

class Player
{
public:
	void PrintAnyThing()
	{
		if(_ptr != nullptr)
			_ptr();
	}

	void CallBackPet(Pet* pet)
	{
		if (_petFn != nullptr && pet != nullptr)
		{
			(pet->*_petFn)();
		}
	}

	void SetFN(FN ptr) { _ptr = ptr; }
	void SetPetFN(FN_Pet ptr) { _petFn = ptr; }

private:
	FN _ptr;
	FN_Pet _petFn;
};

bool CompareInt(const int& a, const int& b)
{
	if (a > b)
		return true;
	return false;
}

int FuncPointer()
{
	int arr[7] = { 5,10,2,3,4,8,1 };

	std::sort(&arr[0], &arr[7], CompareInt);

	return 0;
}