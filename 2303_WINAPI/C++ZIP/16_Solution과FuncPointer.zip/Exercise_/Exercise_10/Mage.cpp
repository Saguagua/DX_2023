#include "Mage.h"

Mage::Mage()
{

}

Mage::Mage(int hp) : Player(hp)
{

}

Mage::~Mage()
{

}

