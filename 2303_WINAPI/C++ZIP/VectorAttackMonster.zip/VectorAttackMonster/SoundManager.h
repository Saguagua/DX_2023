#pragma once
class SoundManager
{
private:
	SoundManager();
	~SoundManager();

public:
	static void Create()
	{
		if (_instance == nullptr)
			_instance = new SoundManager();
	}

	static void Delete()
	{
		if (_instance != nullptr)
		{
			delete _instance;
			_instance = nullptr;
		}
	}

	static SoundManager* GetInstance()
	{
		if (_instance != nullptr)
			return _instance;

		return nullptr;
	}

	void Csound() { cout << _creatureSound << endl; }
	void Psound() { cout << _playerSound << endl; }
	void Msound() { cout << _monsterSound << endl; }
	void C_Csound() { cout << _createCreatureSound << endl; }
	void C_Psound() { cout << _createPlayerSound << endl; }
	void C_Msound() { cout << _createMonsterSound << endl; }

private:
	static SoundManager* _instance;

	string _creatureSound;
	string _playerSound;
	string _monsterSound;
	string _createCreatureSound;
	string _createPlayerSound;
	string _createMonsterSound;

};

