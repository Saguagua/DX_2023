#pragma once


class Monster;

class Player : public Creature
{
public:
	Player();
	Player(int hp, int atk, string name);
	virtual ~Player();

	virtual void AttackMonsters(vector<Monster>& arr);
	virtual void Attack(Creature& other);

private:

};

