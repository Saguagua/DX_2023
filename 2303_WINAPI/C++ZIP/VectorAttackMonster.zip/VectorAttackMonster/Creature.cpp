#include "framework.h"
#include "Creature.h"

Creature::Creature(int hp, int atk, string name)
	:_hp(hp), _atk(atk), _name(name), _isAlive(true)
{
}

Creature::Creature()
	: _hp(100), _atk(10), _name("BasicCreature"), _isAlive(true)
{
	SoundManager::GetInstance()->C_Csound();
}

Creature::~Creature()
{
}

void Creature::SetInfo(int hp, int atk, string name)
{
	if (this == nullptr)
		return;
	_hp = hp;
	_atk = atk;
	_name = name;
}

void Creature::PrintInfo()
{
	if (_isAlive == false) return;
	cout << "�̸�: " << _name << endl;
	cout << "ü��: " << _hp << endl;
	cout << "���ݷ�: " << _atk << endl;
}

void Creature::Attack(Creature& other)
{
	if (_isAlive == false || other.IsAlive() == false)
		return;
	SoundManager::GetInstance()->Csound();
	other.Damged(this->_atk);

	if (other.IsAlive() == true)
		cout << other.GetName() << "�� ���� ü����" << other.GetHP() << endl;
}

void Creature::Damged(int amount)
{
	if (amount <= 0 || _isAlive == false)
		return;

	_hp -= amount;

	if (_hp <= 0)
	{
		cout << _name << "�� �׾����ϴ�." << endl;
		_hp = 0;
		_isAlive = false;
	}
}
