#include "framework.h"
#include "Player.h"

Player::Player()
{
	_hp = 1000;
	_atk = 20;
	_name = "BasicPlayer";
	_isAlive = true;
}

Player::Player(int hp, int atk, string name)
	:Creature(hp, atk, name)
{
	SoundManager::GetInstance()->C_Psound();
}

Player::~Player()
{
}


void Player::AttackMonsters(vector<Monster>& arr)
{
	for (int i = 0; i < arr.size(); i++)
	{
		this->Attack(arr[i]);
	}
}

void Player::Attack(Creature& other)
{

	if (_isAlive == false || other.IsAlive() == false)
		return;
	SoundManager::GetInstance()->Psound();
	other.Damged(this->_atk);

	if (other.IsAlive() == true)
		cout << other.GetName() << "�� ���� ü����" << other.GetHP() << endl;
}
