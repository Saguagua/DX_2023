#include "framework.h"
#include "Monster.h"

Monster::Monster()
{
	_hp = 50;
	_atk = 2;
	_name = "BasicMonster";
	_isAlive = true;
}

Monster::Monster(int hp, int atk, string name)
	:Creature(hp, atk, name)
{
	SoundManager::GetInstance()->C_Msound();
}

Monster::~Monster()
{
}


void Monster::Attack(Creature& other)
{

	if (_isAlive == false || other.IsAlive() == false)
		return;
	SoundManager::GetInstance()->Msound();
	other.Damged(this->_atk);

	if (other.IsAlive() == true)
		cout << other.GetName() << "�� ���� ü����" << other.GetHP() << endl;
}