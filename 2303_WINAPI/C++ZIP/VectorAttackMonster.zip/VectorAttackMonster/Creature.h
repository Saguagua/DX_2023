#pragma once
class Creature
{
public:
	Creature(int hp, int atk, string name);
	Creature();
	virtual ~Creature();

	void SetInfo(int hp, int atk, string name);

	void PrintInfo();

	virtual void Attack(Creature& other);

	void Damged(int amount);

	bool IsAlive() { return _isAlive; }
	const int GetHP() { return _hp; }
	const int GetAtk() { return _atk; }
	const string& GetName() { return _name; }


protected:
	int _hp;
	int _atk;
	string _name;

	bool _isAlive;
};

