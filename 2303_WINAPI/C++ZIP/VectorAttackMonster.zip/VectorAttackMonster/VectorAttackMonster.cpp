﻿#include "framework.h"

bool IsAlive_Monsters(vector<Monster>& monster);

int main()
{
	SoundManager::Create();


	vector<Player> player;
	player.push_back(Player(2000, 50, "player"));

	vector<Monster> monster;
	monster.reserve(10);
	for (int i = 0; i < monster.capacity(); i++)
	{
		string nth = to_string(i + 1) + "Goblin";
		monster.push_back(Monster(100 + 10*i, 10+i, nth));
	}
		cout << endl;

	while (true)
	{

		player[0].AttackMonsters(monster);

		cout << endl;

		for (int i = 0; i < monster.size(); i++)
		{
			monster[i].Attack(player[0]);
		}

		cout << endl;

		if (IsAlive_Monsters(monster) == false)
		{
			cout << "승리!" << endl;
			break;
		}

		if (player[0].IsAlive() == false)
		{
			cout << "패배!" << endl;
			break;
		}
	}


	SoundManager::Delete();

	return 0;
}


bool IsAlive_Monsters(vector<Monster>& monster)
{
	for (int i = 0; i < monster.size(); i++)
	{
		if (monster[i].IsAlive())
		{
			return true;
		}
	}
	return false;
}