#pragma once
class Monster : public Creature
{
};

